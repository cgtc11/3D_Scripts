"""SpringBlender Ver0.1 extension entry point."""

from .SpringBlender import register, unregister

__all__ = ("register", "unregister")

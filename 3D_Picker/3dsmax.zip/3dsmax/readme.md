3dsmax用です。2025で確認してます<br>
 <br>
<img alt="BipedScaler" src="https://github.com/cgtc11/image/blob/main/PickerEditor_MAX2.png" /><br>
<br>
インストールにはフォルダ内のアイコンやスクリプトも使用するので<br>
この階層以下全て纏めてディスクトップ等管理者権限の無い場所へダウンロードしてからインストールしてください<br>
<br>
インストール手順.txt ・・・インストール手順と使い方を記載、必ず読んでください<br>
<br>
MAXはBipedのメニューが出た状態で骨を選択すると少し時間がかかるので<br>
キー入力系のBipedKeyスクリプトも作成してます<br>
<br>
sampleDataフォルダ内にBipedで設定した画像とセーブデータを置いてます<br>
